#ifndef GL_INCLUDES_H_INCLUDED
#define GL_INCLUDES_H_INCLUDED

// Use GLEW for OpenGL Extensions
#include <GL/glew.h>
#include <glfw/glfw3.h>

#endif // GL_INCLUDES_H_INCLUDED
