#ifndef Example2GL_Includes_h
#define Example2GL_Includes_h

// Use GLEW for OpenGL Extensions
#include <GL/glew.h>
#include <glfw/glfw3.h>

#endif
