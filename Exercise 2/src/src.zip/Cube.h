#ifndef Example2_Cube_h
#define Example2_Cube_h

#include "Shape.h"

namespace cgCourse
{
	class Cube : public Shape
	{
	public:
		Cube();
	};
}

#endif
