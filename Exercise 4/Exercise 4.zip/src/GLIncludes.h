#ifndef Example_GLIncludes_h
#define Example_GLIncludes_h

// Use GLEW for OpenGL Extensions
#include <GL/glew.h>
#include <glfw/glfw3.h>

#endif
